//
//  ProfileCardAppApp.swift
//  ProfileCardApp
//
//  Created by Mehmet Ali Sevdinoğlu on 26.08.2025.
//

import SwiftUI

@main
struct ProfileCardAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
