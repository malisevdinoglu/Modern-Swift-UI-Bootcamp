import SwiftUI

struct ContentView: View {
    var body: some View {
        // Tüm ekran kayabilir: About kısmı uzun olabilir
        ScrollView {
            VStack(spacing: 16) {

                // MARK: - ÜST BÖLÜM (HEADER) - Gradient + Profil + İsim + Açıklama
                ZStack {
                    // Arkaplan gradient
                    LinearGradient(
                        colors: [Color.purple.opacity(0.9), Color.blue],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .frame(height: 260)
                    .clipShape(RoundedRectangle(cornerRadius: 24))

                    VStack(spacing: 10) {
                        ProfileImageView()
                            .frame(width: 100, height: 100)

                        Text("Mehmet Ali Sevdinoğlu")
                            .font(.title2.bold())
                            .foregroundStyle(.white)

                        Text("iOS Developer Adayı • Swift & SwiftUI öğreniyorum")
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.white.opacity(0.95))
                            .padding(.horizontal)
                    }
                    .padding(.top, 8)
                }
                .padding(.horizontal)

                // MARK: - BİLGİ KARTLARI (HStack - Eşit Genişlik)
                HStack(spacing: 12) {
                    InfoCard(title: "Takipçi", value: "1.2K", systemIcon: "person.2.fill")
                    InfoCard(title: "Takip",   value: "180", systemIcon: "person.crop.circle.badge.checkmark")
                    InfoCard(title: "Beğeni",  value: "4.8K", systemIcon: "heart.fill")
                }
                .padding(.horizontal)

                // MARK: - HAKKIMDA
                VStack(alignment: .leading, spacing: 8) {
                    Text("Hakkımda")
                        .font(.headline)
                    Text("""
Merhaba! Ben Mehmet Ali. Bilgisayar Mühendisliği mezunuyum ve iOS geliştirme yolculuğuna yeni başlıyorum. Swift ve SwiftUI ile arayüz tasarlamayı, temiz kod yazmayı ve gerçek dünya projeleri üretmeyi hedefliyorum.

Boş zamanlarımda algoritma çalışır, teknik bloglar okur ve açık kaynak projelere katkı denemeleri yaparım. Hedefim: App Store’a ilk uygulamamı yayınlamak! 🚀
""")
                        .font(.body)
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal)

                // MARK: - BUTONLAR (HStack veya VStack tercihine göre)
                HStack(spacing: 12) {
                    Button(action: {
                        // Mesaj Gönder aksiyonu
                    }) {
                        Label("Mesaj Gönder", systemImage: "paperplane.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)

                    Button(action: {
                        // Takip Et aksiyonu
                    }) {
                        Label("Takip Et", systemImage: "plus.circle.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }
                .padding(.horizontal)
                .padding(.bottom, 24)
            }
            .padding(.top, 16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Profil")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Profil Görseli (Varlık varsa onu, yoksa SF Symbol)
struct ProfileImageView: View {
    var body: some View {
        // "profile" adında bir görsel eklemediysen otomatik SF Symbol gösterir
        ZStack {
            if UIImage(named: "profile") != nil {
                Image("profile")
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "person.crop.circle.fill")
                    .resizable()
                    .scaledToFit()
                    .symbolRenderingMode(.hierarchical)
                    .padding(10)
                    .foregroundStyle(.white)
                    .background(Color.white.opacity(0.15))
            }
        }
        .clipShape(Circle())
        .overlay(Circle().stroke(.white, lineWidth: 3))
        .shadow(radius: 6)
    }
}

// MARK: - Bilgi Kartı Bileşeni (Eşit genişlik için .frame maxWidth: .infinity)
struct InfoCard: View {
    let title: String
    let value: String
    let systemIcon: String

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: systemIcon)
                .font(.title3)
            Text(value)
                .font(.headline)
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .shadow(color: .black.opacity(0.07), radius: 6, x: 0, y: 2)
    }
}

#Preview {
    NavigationView { ContentView() }
}
